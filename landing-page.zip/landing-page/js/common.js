$(function() {
// $(document).ready(function(){
//   $(".owl-carousel").owlCarousel();
// });


console.log('test');
$('.owl-category').owlCarousel({
    loop:false,
    dots: false,
    margin:2,
    responsiveClass:true,
    responsive:{
        0:{
            items:2,
            nav:false
        },
        576:{
            items:3,
            nav:false
        },
        768:{
            items:4,
            nav:false
        },
        992:{
            items:5,
            nav:false,
        },
        1200:
            {
            items:6,
            nav:false
        }
    }
})
$('.owl-works').owlCarousel({
    loop: false,
    dots: false,
    margin: 15,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:false
        },
        600:{
            items:2,
            nav:false
        },
        1000:{
            items:4,
            nav:false,
        }
    }
})
$('.categories').owlCarousel({
    loop:false,
    dots: false,
    margin:2,
    responsiveClass:true,
    responsive:{
        0:{
            items:2,
            nav:false
        },
        576:{
            items:3,
            nav:false
        },
        768:{
            items:4,
            nav:false
        },
        992:{
            items:5,
            nav:false,
        },
        1200:
            {
            items:6,
            nav:false
        }
    }
})

function get_rand_color()
{
    var color = Math.floor(Math.random() * Math.pow(256, 3)).toString(16);
    while(color.length < 6) {
        color = "0" + color;
    }
    return "#" + color;
}
});

$('.upload').click(function(){
    // $('.upload').css("background", "red");
    $('.popup').css({
        top: "0"
    });

})

/*$(".image-block").hover(function(){
    $('.image-hover').css("top", "0");
    }, function(){
    $('.image-hover').css("display", "none");
  });*/
var colors = ['#6C63FF', '#FBBEBE', '#464353', 'red'];
var random_color = colors[Math.floor(Math.random() * colors.length)];
document.getElementById('title').style.color = random_color;
$('#title').css('background-color', random_color);


console.log('ImageHover width: ' + $('.picture').width());